#include <stdio.h>

int main()
{
    int b[] = { 10, 20, 30, 40 };
    int *ptrB = b;
    int i;
    int desplazamiento;

    printf("\nArreglo b impreso por subindices de arreglos\n");
    for ( i = 0; i < 4; i++ )
        printf( "%d = %d\n", i, b[i]);

    printf("\nArreglo b impreso por desplazamiento\n");
    for ( desplazamiento = 0; desplazamiento < 4; desplazamiento++)
        printf( "%d = %d\n", desplazamiento, *( b + desplazamiento));

    printf("\nApuntador ptrB impreso por subindices de arreglos\n");
    for ( i = 0; i < 4; i++ )
        printf( "%d = %d\n", i, ptrB[ i ] );
 
    printf("\nApuntador ptrB impreso por desplazamiento\n");
    for ( desplazamiento = 0; desplazamiento < 4; desplazamiento++ )
        printf( "%d = %d\n", desplazamiento, *( ptrB + desplazamiento));
   
   return 0;
}







