The contents of this folder are protected by international copyright laws and are for evaluation purposes only. These files remain the property of Soundwave Concepts.

(c) 2005 Greg Hill - Soundwave Concepts